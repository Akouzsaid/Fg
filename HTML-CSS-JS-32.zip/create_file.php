<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // الحصول على اسم الملف من المستخدم
    $filename = basename($_POST['filename']) . ".html";
    
    // معالجة رفع الفيديو
    $targetDir = "videos/"; // مسار المجلد الذي سيتم تخزين الفيديوهات فيه
    $videoName = basename($_FILES["video"]["name"]);
    $targetFile = $targetDir . $videoName;

    // التحقق من نوع الملف
    $videoFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    if ($videoFileType != "mp4") {
        echo "فقط ملفات MP4 مسموح بها.";
        exit;
    }

    // نقل الفيديو إلى المجلد المحدد
    if (move_uploaded_file($_FILES["video"]["tmp_name"], $targetFile)) {
        echo "تم رفع الفيديو بنجاح.";

        // تحديد محتوى الملف مع تضمين الفيديو
        $content = "<!DOCTYPE html>
<html lang='ar'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>$filename</title>
</head>
<body>
    <h1>مرحباً بك في صفحة $filename</h1>
    <p>تم إنشاء هذه الصفحة ديناميكيًا بواسطة PHP.</p>
    <video controls>
        <source src='$targetFile' type='video/mp4'>
        متصفحك لا يدعم عنصر الفيديو.
    </video>
</body>
</html>";

        // إنشاء الملف وتخزينه
        file_put_contents($filename, $content);

        // عرض رابط للملف الجديد
        echo "<h2>تم إنشاء الملف بنجاح:</h2>";
        echo "<a href='$filename' target='_blank'>افتح $filename</a>";
    } else {
        echo "حدث خطأ أثناء رفع الفيديو.";
    }
} else {
    echo "خطأ في الطلب.";
}
?>